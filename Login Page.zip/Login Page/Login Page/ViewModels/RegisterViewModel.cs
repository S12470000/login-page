﻿using System.ComponentModel.DataAnnotations;

namespace Login_Page.ViewModels
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage ="Name is Required.")]
        public required string Name { get; set; }

        [Required(ErrorMessage = "Phone Number is Required.")]
        [Phone(ErrorMessage = "Invalid phone number.")]
        [Display(Name = "Phone Number")]
        public required string PhoneNumber { get; set; }


        [Required(ErrorMessage = "Email is Required.")]
        [EmailAddress]
        public required string EmailAddress { get; set; }

        [Required(ErrorMessage = "Password is Required.")]
        [StringLength(40, MinimumLength = 8, ErrorMessage = "The {0} must be at{2} and at max {1} character long.")]
        [DataType(DataType.Password)]
        [Compare("ConfirmPassword", ErrorMessage = "Password does not match. ")]
        public required string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password is Required.")]
        [DataType(DataType.Password)]
        [Display(Name = " Confirm Password")]
        public string ConfirmPassword { get; set; } = string.Empty;

    }
}
